import React from 'react';

type UserMenuProps = {
    user: User | null;
    unreadMessagesCount: number;
};

export const UserMenu: React.FC<UserMenuProps> = ({ user, unreadMessagesCount }) => {
    return (
        <div className="flex items-center justify-between">
            <span className="text-xl">Hello, {user?.fullName || 'Guest'}</span>
            <div className="flex items-center">
                {unreadMessagesCount > 0 && (
                    <span className="bg-red-500 text-white rounded-full p-2">{unreadMessagesCount}</span>
                )}
            </div>
        </div>
    );
};
